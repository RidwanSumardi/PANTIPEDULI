package com.ridwan.pantipeduli

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class edit_akun : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_akun)
    }
}